/****************************************************************************
programa que lê um número e imprime se este número é par ou ímpar.
*****************************************************************************/

var prompt = require('prompt-sync')(); // Adiciona a biblioteca prompt-sync

var Numero = Number(prompt("Digite um número: ")); // Converte a entrada para número

if (Numero % 2 == 0) { // Verifica se o número é par
  console.log("Par");
} else {
  console.log("Ímpar");
}