/***************************************************************************
Autora: Isabele Caamano
um programa que determine se um dado número N (digitado pelo usuário) é primo ou não.
*****************************************************************************/

var prompt = require('prompt-sync')();

var numero = Number(prompt("Digite o número:"));
